import os #so we can read the agent count
import random #starting stats
import psycopg2 #postgres
from psycopg2.extras import execute_values #for inserting everyone at once

TOTAL = int(os.environ.get("ZOMBIE_AGENTS", 475)) #total agents, 475 is what stage 1 had (350 humans + 125 zombies)
NUM_ZOMBIES = TOTAL * 125 // 475 #how many zombies 25% of 500
NUM_HUMANS = TOTAL - NUM_ZOMBIES #how many people 75% of 500
WIDTH = HEIGHT = round(1000 * (TOTAL / 475) ** 0.5) #Width and height of map 1000x1000, bigger map with more agents so its not more crowded
HUMAN_SPEED = 4.0 #one tick = 4 points a person can move
ZOMBIE_SPEED = 2.6 #slower than humans same thing tho one tick 

def get_connection(): #new connection 
    return psycopg2.connect(dbname=os.environ.get("ZOMBIE_DB", "zombie_sim2")) #create local "temperary" db, new db name so stage 1 data stays safe (createdb zombie_sim2)

def create_table(): 
    conn = get_connection() #calls def get_connection
    cur = conn.cursor() #sql commands 
    cur.execute("""
        CREATE TABLE IF NOT EXISTS agents (
            agent_id       SERIAL PRIMARY KEY,        -- auto-incrementing unique id per agent
            agent_type     VARCHAR(10) NOT NULL,      -- "human" or "zombie"
            health_status  VARCHAR(10) NOT NULL,      -- healthy/exposed/infected/turned/dead
            x              FLOAT NOT NULL,            -- spawn position, px
            y              FLOAT NOT NULL,            -- spawn position, px
            movement_speed FLOAT NOT NULL,            -- px moved per full tick
            life_value     FLOAT NOT NULL,             -- hit points, drained by fighting
            strength       FLOAT NOT NULL,             -- damage dealt per tick in a fight
            intelligence   FLOAT NOT NULL,             -- gates who's smart enough to research
            susceptibility FLOAT NOT NULL DEFAULT 0,   -- % chance a bite actually infects
            aggression     FLOAT NOT NULL DEFAULT 50   -- % chance a human fights instead of flees
        );
    """) 
    cur.execute("ALTER TABLE agents ADD COLUMN IF NOT EXISTS aggression FLOAT NOT NULL DEFAULT 50;") #sql command 
    cur.execute("""CREATE TABLE IF NOT EXISTS tick_stats (tick INT PRIMARY KEY, humans INT, zombies INT);""") #population every tick
    cur.execute("""CREATE TABLE IF NOT EXISTS agent_final (agent_id INT PRIMARY KEY, agent_type VARCHAR(10),
                   health_status VARCHAR(10), x FLOAT, y FLOAT, life_value FLOAT, susceptibility FLOAT);""") #where everyone ended up
    
    conn.commit() #writes changes 
    cur.close() #close cursor
    conn.close() #close connection 

def seed_agents():
    conn = get_connection() #new connection 
    cur = conn.cursor() #connect cursor again 
    cur.execute("TRUNCATE agents RESTART IDENTITY;") #sql set peeps to one 
    rows = [_insert_agent(cur, "human", "healthy", speed=HUMAN_SPEED) for _ in range(NUM_HUMANS)] #every human gets their own row. people's status and speed (4)
    rows += [_insert_agent(cur, "zombie", "turned", speed=ZOMBIE_SPEED) for _ in range(NUM_ZOMBIES)] #zombies get a row. zombies status is turned always while alive
    execute_values(cur, """INSERT INTO agents (agent_type, health_status, x, y, movement_speed, life_value, strength,
                   intelligence, susceptibility, aggression) VALUES %s""", rows, page_size=10000) #one big insert instead of one per agent
    cur.execute("TRUNCATE tick_stats; TRUNCATE agent_final;") #fresh results tables for this run
    conn.commit() #commit so it will work
    cur.close()
    conn.close()

def _insert_agent(cur, agent_type, health_status, speed): #gives agents random stats 
    x, y = random.uniform(0, WIDTH), random.uniform(0, HEIGHT) #random spawn
    strength = random.uniform(5, 15) #damage in a fight 
    intelligence = random.uniform(1, 10) #above 5 can work in lab 
    aggression = random.uniform(0, 100) #fight vs flee 
    if agent_type == "human": #for humans only 
        susceptibility = random.uniform(80, 99) #susceptibility starts high
    else:
        susceptibility = 0 #zombies even former humans will have 0 susceptibility cause theyre already zombies 
    return (agent_type, health_status, x, y, speed, 100, strength, intelligence, susceptibility, aggression) #sql give them rolled values, returns the row so we can insert everyone at once

def load_agents():
    """Return every agent row as a list of dicts."""
    conn = get_connection() #new connection 
    cur = conn.cursor()
    cur.execute("""SELECT agent_id, agent_type, health_status, x, y, movement_speed,
                          life_value, strength, intelligence, susceptibility, aggression
                   FROM agents ORDER BY agent_id;""") #select all 
    rows = cur.fetchall() #fetch all 
    cur.close()
    conn.close()
    agents = [] 
    for row in rows:
        agents.append({ #ordered dicts bc main zombie needs dicts.
            "agent_id": row[0], "agent_type": row[1], "health_status": row[2],
            "x": row[3], "y": row[4], "movement_speed": row[5],
            "life_value": row[6], "strength": row[7], 
            "intelligence": row[8], "susceptibility": row[9], "aggression": row[10],
        })
    return agents #initiation

def save_results(history, agents): #saves the population each tick and where everyone ended up
    conn = get_connection() #new connection 
    cur = conn.cursor() #cursor again 
    cur.execute("TRUNCATE agent_final") #clear the old final state first, a resumed run saves again
    execute_values(cur, "INSERT INTO tick_stats (tick, humans, zombies) VALUES %s ON CONFLICT (tick) DO NOTHING", history) #tick, humans, zombies
    execute_values(cur, "INSERT INTO agent_final VALUES %s ON CONFLICT (agent_id) DO NOTHING",
                   [(a["agent_id"], a["agent_type"], a["health_status"], a["x"], a["y"], a["life_value"],
                     a["susceptibility"]) for a in agents], page_size=10000) #every agent's final spot and health
    conn.commit() #write it
    cur.close() #close cursor
    conn.close() #close connection
