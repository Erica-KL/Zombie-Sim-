import argparse, contextlib, datetime, hashlib, io, json, os, platform, subprocess, sys, time

ap = argparse.ArgumentParser()
ap.add_argument("--agents", type=int, default=475)
ap.add_argument("--workers", type=int, default=1)
ap.add_argument("--ticks", type=int, default=3)
ap.add_argument("--table", action="store_true") #run every experiment and write results.md
ap.add_argument("--sizes", default="475,2000,5000,10000,20000") #agent counts for --table (475 = the stage 1 population)
ap.add_argument("--store", choices=["none", "memory", "postgres"], default="none") #midterm storage: where the whole state is saved every tick
ap.add_argument("--resume", action="store_true") #start from whatever the store has instead of a new population
args = ap.parse_args()


def run_one(n, workers, ticks, store_kind="none", resume=False):
    os.environ["ZOMBIE_AGENTS"] = str(n) #db.py reads this when it is imported
    import random, db, simulation
    from zombie_storage import InMemoryStore, PostgresStore #storage classes from the midterm
    simulation.WORKERS = workers #after the import, zombie_storage sets it too
    STEPS_PER_TICK, MOVE_INTERVAL = 10, 0.1 #same as mainzombie.py
    store = {"none": None, "memory": InMemoryStore, "postgres": PostgresStore}[store_kind]
    store = store() if store else None
    state = store.load() if (store and resume) else None #midterm: load the whole state, None if nothing is stored
    if state: #resuming: agents, tick and history come back from the store
        agents, tick, history = state["agents"], state["runtime"]["tick"], state["runtime"]["history"]
    else:
        random.seed(42)
        db.create_table(); db.seed_agents() #database: bulk seed ...
        agents = db.load_agents() #... and load
        simulation.init_state(agents)
        history, tick = [], 0
    saving, t0 = 0.0, time.perf_counter() #saving = seconds spent writing to the store
    with contextlib.redirect_stdout(io.StringIO()): #simulation prints every event; silence it
        for _ in range(ticks):
            random.seed(tick) #same dice for a tick whether or not the run was resumed
            for _ in range(STEPS_PER_TICK):
                simulation.step(agents, dt=MOVE_INTERVAL, night=simulation.is_night(tick))
                simulation.check_collisions(agents, tick, dt=MOVE_INTERVAL)
            tick += 1
            simulation.check_bites(agents, tick)
            simulation.advance_infections(agents)
            simulation.advance_exposure(agents)
            simulation.deliver_medicine(agents, tick)
            simulation.advance_research(agents, tick)
            simulation.decide_stances(agents)
            history.append([tick, sum(a["agent_type"] == "human" and a["health_status"] != "dead" for a in agents),
                            sum(a["agent_type"] == "zombie" and a["health_status"] != "dead" for a in agents)])
            if store: #midterm style: save the whole state (agents, environment, runtime) after every tick
                t1 = time.perf_counter()
                store.save({"agents": agents, "environment": {"width": db.WIDTH, "height": db.HEIGHT},
                            "runtime": {"tick": tick, "history": history}})
                saving += time.perf_counter() - t1
    secs = time.perf_counter() - t0
    db.save_results(history, agents) #database: per-tick populations + final state
    digest = hashlib.sha256(repr([(a["health_status"], round(a["x"], 6), round(a["y"], 6)) for a in agents]).encode()).hexdigest()[:12]
    return dict(agents=n, workers=workers, ticks=ticks, store=store_kind, s_per_tick=round(secs / ticks, 2),
                save_s_per_tick=round(saving / ticks, 2), humans=history[-1][1], zombies=history[-1][2], tick=tick, digest=digest)


def sub(n, w, t, store="none", resume=False): #each run in a fresh process because db.py reads the agent count at import
    out = subprocess.run([sys.executable, __file__, "--agents", str(n), "--workers", str(w), "--ticks", str(t), "--store", store]
                         + (["--resume"] if resume else []),
                         capture_output=True, text=True, check=True).stdout
    return json.loads(out.strip().splitlines()[-1])


if not args.table:
    print(json.dumps(run_one(args.agents, args.workers, args.ticks, args.store, args.resume)))
else:
    out = []
    def emit(line=""): #keep a line, everything gets printed once at the bottom
        out.append(line)
    sizes = [int(x) for x in args.sizes.split(",")]
    print("running, results print at the bottom when it's done...", flush=True)
    cpus = os.cpu_count() or 2
    ws = [1] + [w for w in (2, 4, 8) if w <= cpus] #worker counts to test on this machine
    N, T = max(sizes), 3 #N = biggest population, T = ticks per run (10 steps per tick)
    try: chip = subprocess.run(["sysctl", "-n", "machdep.cpu.brand_string"], capture_output=True, text=True).stdout.strip() #mac chip name
    except Exception: chip = ""
    emit("# Stage 2 experiment results (written by benchmark.py --table)\n")
    emit(f"- date: {datetime.datetime.now():%Y-%m-%d %H:%M}")
    emit(f"- machine: {chip or platform.processor() or platform.machine()}, {platform.platform()}, {cpus} CPUs, Python {platform.python_version()}")
    emit(f"- worker counts tested: {ws}; agent counts tested: {sizes}; {T} ticks per run, 10 steps per tick")
    emit("- population of the Stage 1 default: 475 agents (350 humans + 125 zombies)\n")
    emit(f"## Strong scaling: {N:,} agents, {T} ticks\n\n| workers | s/tick | speedup | digest |\n|---|---|---|---|")
    base = None
    for w in ws:
        r = sub(N, w, T); base = base or r["s_per_tick"]
        emit(f"| {w} | {r['s_per_tick']} | {base / r['s_per_tick']:.2f}x | {r['digest']} |")
    emit(f"\n(digest = fingerprint of every agent's status and position at the end; equal digests mean the same final state)")
    emit(f"\n## Population scaling ({ws[-1]} workers, {T} ticks)\n\n| agents | s/tick |\n|---|---|")
    for n in sizes:
        emit(f"| {n:,} | {sub(n, ws[-1], T)['s_per_tick']} |")
    emit(f"\n## Keeping the whole state in a store every tick ({N:,} agents, {ws[-1]} workers, {T} ticks)\n\n| store | s/tick | of that, saving |\n|---|---|---|")
    for kind in ("none", "memory", "postgres"):
        r = sub(N, ws[-1], T, kind)
        emit(f"| {kind} | {r['s_per_tick']} | {r['save_s_per_tick']} |")
    straight = sub(3000, 1, 3) #3 ticks in one go
    sub(3000, 1, 2, "postgres") #2 ticks, state saved in postgres after each
    resumed = sub(3000, 1, 1, "postgres", resume=True) #new process loads the state from postgres and runs 1 more tick
    emit(f"\n## Resume check (3,000 agents)\n\n3 ticks straight = `{straight['digest']}`; 2 ticks, then resume from postgres for 1 more "
         f"(now at tick {resumed['tick']}) = `{resumed['digest']}` -> {'same' if straight['digest'] == resumed['digest'] else 'DIFFERENT'}")
    open(os.path.join(os.path.dirname(os.path.abspath(__file__)), "results.md"), "w").write("\n".join(out) + "\n")
    print("\n" + "\n".join(out) + "\n\n(also saved to results.md)")
