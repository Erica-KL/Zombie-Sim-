#imports
import json, os, random, sys, threading, time
from abc import ABC, abstractmethod
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
import db, simulation

simulation.WORKERS = int(os.environ.get("ZOMBIE_WORKERS", 1)) #more than 1 = parallel neighbour finding and events from simulation.py
PORT, STEP, STEPS_PER_TICK = 8001, 0.1, 10 #define port for web step and steps for ticks (crucial for function)

# store
class StateStore(ABC): 
    
    @abstractmethod #program fails if theres no load
    def load(self): """return the whole state dict, or None if nothing is stored"""
    @abstractmethod #program fails if theres no save.
    def save(self, state): """persist the whole state dict"""

class InMemoryStore(StateStore):
    def __init__(self): self.state = None #nothing is stored yet
    def load(self): return self.state #loads real state
    def save(self, state): self.state = state #updates real state

class PostgresStore(StateStore):
    def __init__(self):
        import psycopg2 #only needed here, so the in-memory store runs without postgres installed
        self.conn = db.get_connection() #open and keep ONE connection (db.py points at zombie_sim2 now so the stage 1 database stays untouched)
        with self.conn, self.conn.cursor() as c:   #if all good move forward
            c.execute("CREATE TABLE IF NOT EXISTS state (key TEXT PRIMARY KEY, data JSONB NOT NULL)") #creates primary key and data collumns 
    def load(self):
        with self.conn, self.conn.cursor() as c: #all good move forward end when done
            c.execute("SELECT key, data FROM state") #run selct collumns from table
            return dict(c.fetchall()) or None #pairs 
    def save(self, state): 
        with self.conn, self.conn.cursor() as c: #all good move forward 
            c.executemany("INSERT INTO state VALUES (%s, %s) ON CONFLICT (key) DO UPDATE SET data = EXCLUDED.data", #sql CONFLICT MANAGEMENT!!! 
                          [(k, json.dumps(v)) for k, v in state.items()]) #3 pairs 

# simulation
class Simulation:
    def __init__(self, store, resume=False): #empty? if so make new one
        self.store, self.lock = store, threading.Lock() 
        if not (resume and store.load()): #resumes 
            store.save(self.new_state()) #builds over the current state 

    @staticmethod
    def new_state():
        agents = [] #hold agents 
        for kind, n, status, speed in (("human", db.NUM_HUMANS, "healthy", db.HUMAN_SPEED), #human fundemental 
                                       ("zombie", db.NUM_ZOMBIES, "turned", db.ZOMBIE_SPEED)): #zombie fundemental
            for _ in range(n):
                agents.append({"agent_id": len(agents) + 1, "agent_type": kind, "health_status": status, #generate basic agent stats 
                               "x": random.uniform(0, db.WIDTH), "y": random.uniform(0, db.HEIGHT), #1000x1000 grid 
                               "movement_speed": speed, "life_value": 100, #movement speed and total life value 
                               "strength": random.uniform(5, 15), "intelligence": random.uniform(1, 10), #strength determines fighting agents above 5 can research 
                               "susceptibility": random.uniform(80, 99) if kind == "human" else 0, #succeptibilty comparison of bite attempt
                               "aggression": random.uniform(0, 100)}) #roles then closes flight or flight
        simulation.init_state(agents) #add runtime 
        return {"agents": agents, #return value
                "environment": {"width": db.WIDTH, "height": db.HEIGHT, "lab_bounds": simulation.LAB_BOUNDS, #width height lab bounds
                                "day_length": simulation.DAY_LENGTH, "research_ticks": simulation.RESEARCH_TICKS}, #day length research ticks
                "runtime": {"tick": 0, "steps": 0, "paused": True, "medicine_produced": 0, "history": []}} #tick steps paused medicine produced

    def advance(self):
        with self.lock:
            s = self.store.load() #load 
            a, rt = s["agents"], s["runtime"] #shortcuts
            if rt["paused"]: return #paused
            simulation.step(a, dt=STEP, night=simulation.is_night(rt["tick"])) #night
            simulation.check_collisions(a, rt["tick"], dt=STEP) #drain health and bite attempts
            rt["steps"] += 1 #step up
            if rt["steps"] >= STEPS_PER_TICK: #10 steps per tick
                rt["steps"], rt["tick"] = 0, rt["tick"] + 1 #passage of time
                simulation.check_bites(a, rt["tick"]) #bite roll
                simulation.advance_infections(a) #status count down
                simulation.advance_exposure(a) #status count down
                simulation.deliver_medicine(a, rt["tick"]) #deliver medecine 
                rt["medicine_produced"] += simulation.advance_research(a, rt["tick"]) #doses finished 
                simulation.decide_stances(a) #fight or flight 
                rt["history"].append([rt["tick"], self.count(a, "human"), self.count(a, "zombie")]) #tick living humans
            self.store.save(s) #write

    @staticmethod
    def count(agents, kind):
        return sum(1 for a in agents if a["agent_type"] == kind and a["health_status"] != "dead") #agents who arent dead 

    def toggle_pause(self):
        with self.lock: #with lock 
            s = self.store.load() #pulls state
            s["runtime"]["paused"] = not s["runtime"]["paused"] #switch
            self.store.save(s) #stores change
            return s["runtime"]["paused"] #sends back new value

    def agents(self):
        with self.lock: return self.store.load()["agents"] #with lock loads state return only agents

    def status(self):
        with self.lock: s = self.store.load() #load with lock ends at bottom 
        a, rt, env = s["agents"], s["runtime"], s["environment"] #agents, runtime, enviornment nickname 
        return {"tick": rt["tick"], "paused": rt["paused"], "day": simulation.day_number(rt["tick"]), #day number 
                "night": simulation.is_night(rt["tick"]), "human_count": self.count(a, "human"), #nightime darken, human count 
                "zombie_count": self.count(a, "zombie"), "medicine_produced": rt["medicine_produced"], #living zombies, med produced
                "medicine_in_circulation": sum(x["medicine_count"] for x in a if x["agent_type"] == "human"), #total carried doses
                "research_ticks": env["research_ticks"], "lab_bounds": env["lab_bounds"], #research progress to percent 
                "day_length": env["day_length"], "width": env["width"], "height": env["height"], #ticket per day day length grid
                "history": rt["history"]} #closes 

# web
class Handler(BaseHTTPRequestHandler):
    log_message = lambda *a: None #collects arguments none is a return
    def reply(self, body, ctype="application/json"): #default json 
        self.send_response(200); self.send_header("Content-Type", ctype); self.end_headers(); self.wfile.write(body)   #send status 200 write body bytes
    def do_GET(self): 
        if self.path in ("/", "/index.html"): self.reply(open("index.html", "rb").read(), "text/html") #if path in / and/index read raw bytes and sends html
        elif self.path == "/agents": self.reply(json.dumps(sim.agents()).encode()) #for agents convert agent list to JSON encode to bytes sends to sim 
        elif self.path == "/status": self.reply(json.dumps(sim.status()).encode()) #same thing but for status 
        elif self.path == "/bench": self.reply(json.dumps(simulation.bench()).encode()) #runs the short tests
        else: self.send_error(404) #404 not found 
    def do_POST(self):
        if self.path != "/pause": return self.send_error(404) #404 not found rejects post 
        self.reply(json.dumps({"paused": sim.toggle_pause()}).encode()) #toggle pause button

if __name__ == "__main__":
    store = PostgresStore() if "--postgres" in sys.argv else InMemoryStore()  #is --postgres in sys.argv
    sim = Simulation(store, resume="--resume" in sys.argv) #is --resume present within sys.argv?
    def clock():
        while True: time.sleep(STEP); sim.advance() #time advances while sleeping 
    threading.Thread(target=clock, daemon=True).start() #runs slower sleep then work
    print(f"Storage demo running at http://localhost:{PORT}") #print the link
    try: ThreadingHTTPServer(("localhost", PORT), Handler).serve_forever() #Server with no expiration date hosted locally
    except KeyboardInterrupt: pass #manuel cancel
